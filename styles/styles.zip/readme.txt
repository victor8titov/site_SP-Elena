
	STYLES TEMPLATE

Description: For work with single page and wordpress theme.
